thesis/writeup
=======

LaTeX files, you know. There's overlap between this folder and thesis/notes.